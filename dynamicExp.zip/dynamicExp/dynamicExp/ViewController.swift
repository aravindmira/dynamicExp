//
//  ViewController.swift
//  dynamicExp
//
//  Created by Aravind on 12/23/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var string = String()
        var x = CGFloat()
        var y = CGFloat()
        y = 30
        x = 0
        string = "alskbdjasd sdihihrwiothiowrtiowrtet lsdfljndjlfbjsdbfjsdf sdlfnjsdbf skdlsadmekwe wkekw klrwroeopewmroemr wpeomrmwe hjfgjhfghcdghc jyfyftgg"
        for i in (0...string.count-1){
            x += 6
            if x>=self.view.frame.size.width {
                x = 0
                y += 28
            }
        }
        print(x,y)
        let label = UITextView(frame: CGRect(x: 0, y: y, width: self.view.frame.size.width, height: y))
        //label.center = CGPoint(x: 160, y: 285)
        //label.textAlignment = .center
        label.backgroundColor = .yellow
       // label.numberOfLines = 30
        label.text = string
        self.view.addSubview(label)
        let cust = UIView(frame: CGRect(x: x, y: y, width: 50, height: 50))
           cust.backgroundColor = .red
        [self.view .addSubview(cust)]
        
    }
   
    


}

